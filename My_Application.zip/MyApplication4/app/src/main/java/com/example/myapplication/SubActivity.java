package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {

    //フィールド宣言
    private SharedPreferences dataStore;
    private SharedPreferences dataStore2;
    private SharedPreferences dataStore3;
    private Spinner spinner;
    private Spinner spinner2;
    private Spinner spinner3;
    private TextView textRead;
    private TextView textRead2;
    private TextView textRead3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        // "DataStore"という名前でインスタンスを生成
        dataStore = getSharedPreferences("SaveData", MODE_PRIVATE);
        dataStore2 = getSharedPreferences("SaveData2", MODE_PRIVATE);
        dataStore3 = getSharedPreferences("SaveData3", MODE_PRIVATE);

        spinner = findViewById(R.id.spinner);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner4);
        textRead = findViewById(R.id.text_read);
        textRead2 = findViewById(R.id.text_read2);
        textRead3 = findViewById(R.id.text_read3);

        Button save = findViewById(R.id.saveButton);
        save.setOnClickListener( v -> {
            //Spinnerのテキストを取得
            String text = spinner.getSelectedItem().toString();
            String text2 = spinner2.getSelectedItem().toString();
            String text3 = spinner3.getSelectedItem().toString();
            textRead.setText(text);
            textRead2.setText(text2);
            textRead3.setText(text3);
            // 入力文字列を"input"に書き込む
            SharedPreferences.Editor editor = dataStore.edit();
            SharedPreferences.Editor editor2 = dataStore2.edit();
            SharedPreferences.Editor editor3 = dataStore3.edit();
            editor.putString("input", text);
            editor2.putString("input2", text2);
            editor3.putString("input3", text3);
            //editor.commit();
            editor.apply();
            editor2.apply();
            editor3.apply();

        });

        Button READ = findViewById(R.id.readButton);
        READ.setOnClickListener( v -> {
            // "input"から読み出す、何もないときは"Nothing"を返す
            String str = dataStore.getString("input", "Nothing");
            String str2 = dataStore2.getString("input2", "Nothing");
            String str3 = dataStore3.getString("input3", "Nothing");
            if(!str.equals("Nothing")) {
                textRead.setText(str);
                textRead2.setText(str2);
                textRead3.setText(str3);
            }

        });
    }

    }